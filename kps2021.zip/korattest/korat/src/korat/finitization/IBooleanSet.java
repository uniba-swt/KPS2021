package korat.finitization;

/**
 * <p>
 * IBooleanSet represents field domain for boolean fields
 * 
 * @author korat.team
 *
 */
public interface IBooleanSet extends IPrimitiveTypeSet {

}
