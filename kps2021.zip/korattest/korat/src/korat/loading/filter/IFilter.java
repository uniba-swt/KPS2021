package korat.loading.filter;

public interface IFilter {

}
