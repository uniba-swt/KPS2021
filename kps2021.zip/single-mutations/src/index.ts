import _ from "lodash";

console.log("index.ts");
