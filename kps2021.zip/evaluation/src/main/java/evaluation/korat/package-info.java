/**
 * adapted from https://github.com/korattest/korat/tree/master/examples/korat/examples
 * commit hash: d3c478df6d73c46ba4643b82bc909eb3f22b2f3a
 *
 * The package doublylinkedlist (Korat naming) contains a cyclic doubly-linked list
 */
package evaluation.korat;